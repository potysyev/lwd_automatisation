from math import *
from TechlogMath import *
from operator import *
import sys
if sys.version_info[0]==3:
    from six.moves import range

PI     = 3.14159265358979323846
PIO2   = 1.57079632679489661923
PIO4   = 7.85398163397448309616E-1
SQRT2  = 1.41421356237309504880
SQRTH  = 7.07106781186547524401E-1
E      = exp(1)
LN2    = log(2)
LN10   = log(10)
LOG2E  = 1.4426950408889634073599
LOG10E = 1.0 / LN10
MissingValue = -9999
def iif(condition, trueResult=MissingValue, falseResult=MissingValue):
	if condition:
		return trueResult
	else:
		return falseResult

#Declarations
#The dictionary of parameters v2.0
#name,bname,type,family,measurement,unit,value,mode,description,group,min,max,list,enable,iscombocheckbox,isused
parameterDict = {}
try:
	if Parameter:
		pass
except NameError:
	class Parameter:
		def __init__(self, **d):
			pass

__author__ = """Victor POTYSYEV (VPOT)"""
__date__ = """2018-08-12"""
__version__ = """1.0"""
__pyVersion__ = """3"""
__group__ = """"""
__suffix__ = """"""
__prefix__ = """"""
__applyMode__ = """0"""
__awiEngine__ = """v1"""
__layoutTemplateMode__ = """"""
__includeMissingValues__ = """True"""
__keepPreviouslyComputedValues__ = """True"""
__areInputDisplayed__ = """True"""
__useMultiWellLayout__ = """True"""
__idForHelp__ = """"""
__executionGranularity__ = """full"""
#DeclarationsEnd
#Скрипт выполняет нормировку кривых ГИС
#Для нормировки разведок коэффициенты должны быть в таблице
#Для корректировки можно изменить датасет _Composite.Normalization 
#НОРМИРОВКА RT НЕ ВЫПОЛНЯЕТСЯ ПО УМОЛЧАНИЮ. Можно отредактировать таблицу

from six.moves import range
def log_hist(list,list_norm,log,w,norm_val, list_p, list_norm_p,horizon=False): #функция сохранения гистограмы 
	
	picpath=db.dirProject()+"\\Various"#путь сохранения гистограм установить путь проекта куда сохраняются картинки с нормализацией
	plt.figure(figsize=(8,6))
	ax = plt.subplot(111)

	plt.grid(True)
	plt.xlabel(log)
	plt.ylabel("Probability")
	
	#параметры гистограмм бля разных методов
	if log=="GR":
		plt.hist([list,list_norm],100,density=True, histtype="step", label=["Before Normalization: "+str(round(list_p,1)),"After Normalization "+str(round(list_norm_p,1))]) 
		plt.xlim(40, 140)
		plt.vlines(norm_val,plt.ylim()[0],plt.ylim()[1],colors="r",linestyles="dashed", label="Calibration / $\\Delta$: "+str(round(norm_val,1))+" / "+str(round(norm_val-list_p,1))+" gAPI")
	elif log=="RHOB":
		plt.hist([list,list_norm],100,density=True, histtype="step", label=["Before Normalization: "+str(round(list_p,3)),"After Normalization "+str(round(list_norm_p,3))]) 
		plt.xlim(2, 2.5)
		plt.vlines(norm_val,plt.ylim()[0],plt.ylim()[1],colors="r",linestyles="dashed", label="Calibration / $\\Delta$: "+str(round(norm_val,3))+" / "+str(round(norm_val-list_p,3))+" g/cc")
	elif log=="TNPH":
		plt.hist([list,list_norm],100,density=True, histtype="step", label=["Before Normalization: "+str(round(list_p,2)),"After Normalization "+str(round(list_norm_p,2))]) 
		plt.xlim(0.6, 0.2)
		plt.vlines(norm_val,plt.ylim()[0],plt.ylim()[1],colors="r",linestyles="dashed", label="Calibration / $\\Delta$: "+str(round(norm_val,2))+" / "+str(round(norm_val-list_p,2))+" v/v")
	elif log=="RT":
		plt.hist([list,list_norm],100,range=(1,10),density=True, histtype="step", label=["Before Normalization: "+str(round(list_p,2)),"After Normalization "+str(round(list_norm_p,2))]) 
		plt.xlim(1, 20)
		plt.xscale("log")
		plt.grid(which="minor", axis="x")
		plt.vlines(norm_val,plt.ylim()[0],plt.ylim()[1],colors="r",linestyles="dashed", label="Calibration / $\\Delta$: "+str(round(norm_val,2))+" / "+str(round(norm_val-list_p,2))+" Ohmm")

	box = ax.get_position()
	ax.set_position([box.x0, box.y0 + box.height * 0.15, box.width, box.height * 0.85])
	# Put a legend below current axis
	ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.1),fancybox=False, shadow=False, ncol=2, borderaxespad=0, frameon=False)

	if horizon:
		plt.title(w+" Horizontal")
		fn = os.path.join(picpath,w+"_hz_"+log )
	else:
		plt.title(w)
		fn = os.path.join(picpath,w+"_"+log )
	if os.path.isfile(fn+".png"):
  		 os.remove(fn+".png")
  
	plt.savefig(fn+".png", format='png')
	plt.clf()
	

#Основной скрипт
import numpy as np
import matplotlib.pyplot as plt
import os

#используемые датасеты
ds="STAT_CPI"
zds="TOPS_PK1_AK_latest" 
norm_base=500 #длина интервала нормировки

norm_table = '_COMPOSITE' #название датасета с таблицей нормалицации
dsn = 'Normalisation'
varZoneName = 'WELL'

gr_norm_val=db.variableLoad(norm_table, dsn, "11_bGR")[0] #стандартное значение ГК для нормировки транспорта которое храница на 0 индексе и опрделено по 113pl
rhob_norm_val=db.variableLoad(norm_table, dsn, "31_bDEN")[0] #стандартное значение ГГКП для нормировки транспорта которое храница на 0 индексе и опрделено по 113pl
tnph_norm_val=db.variableLoad(norm_table, dsn, "21_bTNPH")[0] #стандартное значение НК для нормировки транспорта которое храница на 0 индексе и опрделено по 113pl
rt_norm_val=db.variableLoad(norm_table, dsn, "51_bRT")[0] #стандартное значение УЭС для нормировки транспорта которое храница на 0 индексе и опрделено по 113pl
rt_norm_horizon=db.variableLoad(norm_table, dsn, "53_bRT_hor")[0] #стандартное значение УЭС для нормировки горизонта которое храница на 0 индексе и опрделено по 113pl
lwd_ch=False
cmt=""
for w in db.selectedWellList() :
	print(w)
	lwd_ch=False
	cmt=""
	welllist_norm=db.variableLoad(norm_table, dsn, "WELL")
	if not db.datasetExists(w,ds):
		print("Сделай датасет STAT_CPI")
		break
	#Обьявление переменных и загрузка данных из БД
	md_name=db.referenceName(w,ds)
	MD=Variable(w, ds, md_name)
	
	fld=db.variableLoad(w, ds, "FLD")
	bhf=db.variableLoad(w, ds, "BHF")
	if db.variableExists(w,ds,"RHOB"):
		rhob=db.variableLoad(w, ds, "RHOB")
	if db.variableExists(w,ds,"DTC"):
		dt=db.variableLoad(w, ds, "DTC")
	if db.variableExists(w,ds,"TNPH"):
		tnph=db.variableLoad(w, ds, "TNPH")
	gr=db.variableLoad(w, ds, "GR")
	rt=db.variableLoad(w, ds, "RT")
	horizon=db.variableLoad(w, ds, "HORIZON")
	calc=db.variableLoad(w, ds, "CALC")
	hor_ch=True
	
	#опредление признака данных во время бурения
	if db.variableExists(w,ds,"ALCDBQ") or db.variableExists(w,ds,"ALCDLC") or db.variableExists(w,ds,"ALCDLC-T"):
		lwd_ch=True
	else:
		lwd_ch=False
	
	#обнуление флагов
	den_ch=0
	dt_ch=0
	gr_ch=0
	tnph_ch=0
	rt_ch=0
	
	#определение места начала данных в хвостовике
	if db.variableExists(w,ds,"HORIZON"):
		try:
			a=horizon.index(1)
		except:
			hor_ch=False
	elif lwd_ch:
		print("Выдели флаг HORIZON!")
		break
	
	#проверка наличия кузнецовской свиты в разбивках
	kuz=db.variableLoad(w, zds, "Surface")
	if "KUZ" not in kuz:
		print("Не отбита кузнецовская свита. Автонормировка невозможна")
		continue
	
	start_kuz=db.datasetZoneIndice(w,ds,zds,"KUZ")[0] #Определение индекса кровли Кузнецовской
	stop_kuz=db.datasetZoneIndice(w,ds,zds,"KUZ")[1] #Определение индекса подошвы Кузнецовской
	start_transp=db.datasetZoneIndice(w,ds,zds,"PK1")[0] #Определение индекса кровли Пк1

	if hor_ch: #Если у скважины есть хвостовик то индекс конца транспорта будет равен индексу начала горизонта и индекс определяется выше
		stop_transp=horizon.index(1)
		start_horizon=horizon.index(1)
		if int(norm_base/round(db.datasetSamplingRate(w,ds),1))<MD.referenceSize():
			stop_horizon=int(start_horizon+norm_base/round(db.datasetSamplingRate(w,ds),1))
		else:
			stop_horizon=MD.referenceSize()
	else: #если нет горизонта то траспорт до максимальной глубины датасета
		stop_transp=MD.referenceSize()
		start_horizon=0
		stop_horizon=0
	bhf_kuz=np.array(bhf)[start_kuz:stop_kuz] #массив Numpy с данными состояния ствола в кузнецовской
	
		#Нормировка по Кузнецовской выполняется в пилотах и транспортных но не в старых скважиназх где нет кузнецовской

	gr_kuz=np.array(gr)[start_kuz:stop_kuz] #массив Numpy с данными ГК в кузнецовской
	if np.all(gr_kuz==MissingValue):
		print("Нет значений ГК в Кузнецовской свите")
		continue
	gr_kuz=gr_kuz[gr_kuz>0] #фильтрация положительных значений
	gr_kuz_p=np.percentile(gr_kuz,50) #определяем значение на 50 персентиле (медиану)
	gr_kuz_delta= round(gr_norm_val-gr_kuz_p,1) #определяем разницу между значением в текукущей скважине и нормировочным значением
	
	
	rhob_kuz=np.array(rhob)[start_kuz:stop_kuz] #массив Numpy с данными ГГКП в кузнецовской
	if np.all(rhob_kuz==MissingValue):
		print("Нет значений ГГКП в Кузнецовской свите")
		continue
	rhob_kuz=rhob_kuz[bhf_kuz==0] #фильтрация по флагу состояния ствола
	rhob_kuz=rhob_kuz[rhob_kuz>0 & (rhob_kuz<2.35)] #фильтрация положительных значений и значений меньше 2,35
	rhob_kuz_p=np.percentile(rhob_kuz,90) #определяем значение на 90 персентиле 
	rhob_kuz_delta= round(rhob_norm_val-rhob_kuz_p,3)#определяем разницу между значением в текукущей скважине и нормировочным значением
	
	tnph_kuz=np.array(tnph)[start_kuz:stop_kuz] #массив Numpy с данными НК в кузнецовской
	if np.all(tnph_kuz==MissingValue):
		print("Нет значений НК в Кузнецовской свите")
		continue
	tnph_kuz=tnph_kuz[bhf_kuz==0]  #фильтрация по флагу состояния ствола
	tnph_kuz=tnph_kuz[tnph_kuz>0] #фильтрация положительных значений
	tnph_kuz_p=np.percentile(tnph_kuz,50) #определяем значение на 50 персентиле (медиану)
	tnph_kuz_delta= round(tnph_norm_val-tnph_kuz_p,2)#определяем разницу между значением в текукущей скважине и нормировочным значением
	
	rt_kuz=np.array(rt)[start_kuz:stop_kuz] #массив Numpy с данными УЭС в кузнецовской
	if np.all(rt_kuz==MissingValue):
		print("Нет значений УЭС в Кузнецовской свите")
		continue
	rt_kuz=rt_kuz[rt_kuz>0] #фильтрация положительных значений
	rt_kuz_p=np.percentile(rt_kuz,10) #определяем значение на 10 персентиле 
	rt_kuz_delta= round(rt_norm_val-rt_kuz_p,2)#определяем разницу между значением в текукущей скважине и нормировочным значением
	
	print("Поправочные коэффициенты для транспорта: ГК:",gr_kuz_delta,"ГГКП:",rhob_kuz_delta,"НК:",tnph_kuz_delta,"УЭС:",rt_kuz_delta)

	#Нормировка горизонтального ствола 
	#должны выполнятся только в случае горизонтальной скважины
	if hor_ch: 
		fld_transp=np.array(fld)[start_transp:stop_transp]     #массив Numpy с характером насыщения в транспорте
		fld_horizon=np.array(fld)[start_horizon:stop_horizon]  #массив Numpy с характером насыщения в горизонте
		clc_transp=np.array(calc)[start_transp:stop_transp]    #массив Numpy с флагом кальцита в транспорте
		clc_horizon=np.array(calc)[start_horizon:stop_horizon] #массив Numpy с флагом кальцита в транспорте
		bhf_transp=np.array(bhf)[start_transp:stop_transp]     #массив Numpy с данными состояния ствола в транспорте 
		bhf_horizon=np.array(bhf)[start_horizon:stop_horizon]  #массив Numpy с данными состояния ствола в горизонте
		
		gr_transp=np.array(gr)[start_transp:stop_transp]  #массив Numpy с данными ГК в транспорте
		gr_transp=gr_transp[gr_transp>0] #фильтрация положительных значений
		gr_transp_p=np.percentile(gr_transp,90) #определяем значение на 90 персентиле 
		
		rhob_transp=np.array(rhob)[start_transp:stop_transp]  #массив Numpy с данными ГГКП в транспорте
		rhob_transp=rhob_transp[(rhob_transp>0) & (clc_transp==0)&(bhf_transp==0)] #фильтрация положительных значений, отсутсвие кальцитов и каверн
		rhob_transp_p=np.percentile(rhob_transp,90) #определяем значение на 90 персентиле 
		
		tnph_transp=np.array(tnph)[start_transp:stop_transp]  #массив Numpy с данными НК в транспорте
		tnph_transp=tnph_transp[(tnph_transp>0)&(fld_transp!=3)&(bhf_transp==0)&(clc_transp==0)]  #фильтрация положительных значений, отсутсвие кальцитов и каверн и отсутствия газа
		tnph_transp_p=np.percentile(tnph_transp,70) #определяем значение на 70 персентиле 
		
		rt_transp=np.array(rt)[start_transp:stop_transp] #массив Numpy с данными УЭС в транспорте
		rt_transp=rt_transp[(fld_transp!=1)&(fld_transp<4)] #оставляем тольо нефть и газ
		rt_transp=rt_transp[(rt_transp>0)&(rt_transp<10)] # больше 0 и меньше 10 Jvv
		rt_transp_p=np.percentile(rt_transp,5) #определяем значение на 5 персентиле 
		
		#коэффициенты для горизонта
		
		gr_horizon=np.array(gr)[start_horizon:stop_horizon] #массив Numpy с данными ГК в горизонте
		gr_horizon=gr_horizon[gr_horizon>0]
		gr_horizon_p=np.percentile(gr_horizon,90)
		
		rhob_horizon=np.array(rhob)[start_horizon:stop_horizon] #массив Numpy с данными ГГКП в горизонте
		rhob_horizon=rhob_horizon[(rhob_horizon>0) & (clc_horizon==0)&(bhf_horizon==0)]
		rhob_horizon_p=np.percentile(rhob_horizon,90)
		
		tnph_horizon=np.array(tnph)[start_horizon:stop_horizon]#массив Numpy с данными НК в горизонте
		tnph_horizon=tnph_horizon[(tnph_horizon>0)&(fld_horizon!=3)&(bhf_horizon==0)&(clc_horizon==0)]
		tnph_horizon_p=np.percentile(tnph_horizon,70)
		
		rt_horizon=np.array(rt)[start_horizon:stop_horizon] #массив Numpy с данными УЭС в горизонте
		rt_horizon=rt_horizon[(fld_horizon!=1)&(fld_horizon<=4)]
		rt_horizon=rt_horizon[(rt_horizon>0)&(rt_horizon<10)]
		rt_horizon_p=np.percentile(rt_horizon,5)
		
		#определяем поправочные коэффициенты
		gr_horizon_delta= round((gr_transp_p- gr_horizon_p)+gr_kuz_delta,1)  
		rhob_horizon_delta= round((rhob_transp_p- rhob_horizon_p)+rhob_kuz_delta,3)
		tnph_horizon_delta= round((tnph_transp_p- tnph_horizon_p)+tnph_kuz_delta,2)
		rt_horizon_delta= round(rt_norm_horizon- rt_horizon_p,2)
		
		
		if rhob_horizon_delta<0: #отрицательной движки быть не может иза того что выборка литотипов по горизонту полнее
			rhob_horizon_delta=0
		if rt_horizon_delta>0:
			rt_horizon_delta=0

		print("Поправочные коэффициенты для горизонта: ГК:",gr_horizon_delta,"ГГКП:",rhob_horizon_delta,"НК:",tnph_horizon_delta,"УЭС:",rt_horizon_delta)
	else:
		gr_horizon_delta= MissingValue  
		rhob_horizon_delta=  MissingValue
		tnph_horizon_delta=  MissingValue
		rt_horizon_delta=  MissingValue
	
	if w not in welllist_norm: #создание строки скважины в  таблице нормализации 
		print(w,"not in the list")
		ID=db.variableLoad(norm_table,dsn,"ID")
		db.datasetExpand(norm_table,dsn, 1,len(ID) )
		var_data=db.variableLoad(norm_table, dsn, "WELL")
		var_data[-1]=w
		db.variableSave(norm_table,dsn,"WELL", "","",var_data)
	else:
		print(w, "Скважина присутствует в таблице нормализации. Используются коэффиенты из таблицы")
	
	#заполнение таблицы нормализации
	welllist=db.variableLoad(norm_table, dsn, "WELL")
	w_ind=welllist.index(w) #индекс текущей скважины в таблице нормализации
	for var in db.variableList(norm_table,dsn): #перебираем все нормировочные значения в таблице нормализации
		var_data=db.variableLoad(norm_table, dsn, var)
		#найти индекс скважины
		if var=="WELL":
			var_data[w_ind]=w
		elif var=="ID":
			var_data[w_ind]=int(var_data[w_ind-1])+1
		elif var =="11_bGR": #аддитивная поправка в ГК в транспорте
			if round(var_data[w_ind],1)!=MissingValue and gr_kuz_delta!=round(var_data[w_ind],1) : #Если значение есть в таблице то выводим текст иначе просто вставляем значение
				print("Нормировочное значение ГК в транспорте {} отличается от табличного {}".format(gr_kuz_delta,round(var_data[w_ind],1)))
			else:
				var_data[w_ind]=gr_kuz_delta
		elif var =="21_bTNPH": #аддитивная поправка в НК в транспорте
			if  round(var_data[w_ind],3)!=MissingValue and tnph_kuz_delta!=round(var_data[w_ind],3) : #Если значение есть в таблице то выводим текст иначе просто вставляем значение
				print("Нормировочное значение НК в транспорте {} отличается от табличного {}".format(tnph_kuz_delta,round(var_data[w_ind],3)))
			else:
				var_data[w_ind]=tnph_kuz_delta
		elif var =="31_bDEN": #аддитивная поправка в ГГКП в транспорте
			if  round(var_data[w_ind],3)!=MissingValue and rhob_kuz_delta!=round(var_data[w_ind],3) : #Если значение есть в таблице то выводим текст иначе просто вставляем значение
				print("Нормировочное значение ГГКп в транспорте {} отличается от табличного {}".format(rhob_kuz_delta,round(var_data[w_ind],3)))
			else:
				var_data[w_ind]=rhob_kuz_delta
		elif var =="51_bRT": #аддитивная поправка в УЭС в транспорте
			if var_data[w_ind]!=MissingValue and rt_kuz_delta!=round(var_data[w_ind],2) : #Если значение есть в таблице то выводим текст иначе просто вставляем значение
				print("Нормировочное значение УЭС в транспорте {} отличается от табличного {}".format(rt_kuz_delta,var_data[w_ind]))
			else:
				var_data[w_ind]=0#rt_kuz_delta
		elif var =="14_bGR_hor": #аддитивная поправка в ГК в горизонте
			if gr_horizon_delta!=MissingValue and round(var_data[w_ind],1)!=MissingValue and gr_horizon_delta!=round(var_data[w_ind],1) : #Если значение есть в таблице то выводим текст иначе просто вставляем значение
				print("Нормировочное значение ГК в горизонте {} отличается от табличного {}".format(gr_horizon_delta,round(var_data[w_ind],1)))
			else:
				var_data[w_ind]=gr_horizon_delta
		elif var =="24_bTNPH_hor": #аддитивная поправка в НК в горизонте
			if tnph_horizon_delta!=MissingValue and round(var_data[w_ind],3)!=MissingValue and tnph_horizon_delta!=round(var_data[w_ind],3) : #Если значение есть в таблице то выводим текст иначе просто вставляем значение 
				print("Нормировочное значение НК в горизонте {} отличается от табличного {}".format(tnph_horizon_delta,round(var_data[w_ind],3)))
			else:
				var_data[w_ind]=tnph_horizon_delta
		elif var =="33_bDEN_hor": #аддитивная поправка в ГГКП в горизонте
			if rhob_horizon_delta!=MissingValue and round(var_data[w_ind],3)!=MissingValue and rhob_horizon_delta!=round(var_data[w_ind],3) : #Если значение есть в таблице то выводим текст иначе просто вставляем значение
				print("Нормировочное значение ГГКп в горизонте {} отличается от табличного {}".format(rhob_horizon_delta,round(var_data[w_ind],3)))
			else:
				var_data[w_ind]=rhob_horizon_delta
		elif var =="53_bRT_hor": #аддитивная поправка в УЭС в горизонте
			if rt_horizon_delta!=MissingValue and var_data[w_ind]!=MissingValue and rt_horizon_delta!=round(var_data[w_ind],2) : #Если значение есть в таблице то выводим текст иначе просто вставляем значение
				print("Нормировочное значение УЭС в горизонте {} отличается от табличного {}".format(rt_horizon_delta,var_data[w_ind]))
			else:
				var_data[w_ind]=0#rt_horizon_delta
		elif var[3]=="k": #мультипликативная по умолчанию задается 1
			if var_data[w_ind]=="" or var_data[w_ind]==MissingValue:
				var_data[w_ind]=int(1)
		elif var=="41_bDT" or var=="43_bDT_hor": 
			if var_data[w_ind]=="":
				var_data[w_ind]=0
		elif var=="999_Comment": #коментарий задается пустой строкой
			var_data[w_ind]=cmt
		else:
			var_data[w_ind]=""
		#print(var_data)
		db.variableSave(norm_table,dsn,var, "","",var_data) #сохранение таблицы
		#print(var,"saved")
					
	
	#Модуль применения поправочный коэффициентов к кривым. Вынесен отдельно чтобы была возможность применить коээфициенты после ручной правки в таблице.
	varNames = db.variableList(norm_table, dsn) #список имен переменных в таюблице
	datasetVarData = {var: db.variableLoad(norm_table, dsn, var) for var in varNames} #запонение списка значениями таблицы
	zoneInfo = {datasetVarData[varZoneName][n]: {var: datasetVarData[var][n] for var in varNames} for n in range(db.datasetSize(norm_table, dsn))} #создание словаря из списка имен и значений

	#присвоение значений
	if db.variableExists(w,ds,"RHOB"):
		rhob_norm=Variable(w, ds, "RHOB_NORM","Bulk Density", "g/cm3")
		den_ch=1
		
		kDEN=float(zoneInfo[w]["30_kDEN"]) #мультипликативная поправка ГГКп в траспорте
		bDEN=float(zoneInfo[w]["31_bDEN"]) #аддитивная поправка в ГГКП в транспорте
		
		kDEN_hor=float(zoneInfo[w]["32_kDEN_hor"])  #мультипликативная поправка ГГКп в горизонте
		bDEN_hor=float(zoneInfo[w]["33_bDEN_hor"]) #аддитивная поправка в ГГКП в горизонте
		
	if db.variableExists(w,ds,"DTC"):
		dt_norm=Variable(w, ds, "DTC_NORM", "Compressional Slowness", "us/m")
		dt_ch=1
		
		kDT=float(zoneInfo[w]["40_kDT"]) #мультипликативная поправка АК в траспорте
		bDT=float(zoneInfo[w]["41_bDT"]) #аддитивная поправка в АК в транспорте
		
		kDT_hor=float(zoneInfo[w]["42_kDT_hor"]) #мультипликативная поправка АК в горизонте
		bDT_hor=float(zoneInfo[w]["43_bDT_hor"]) #аддитивная поправка в АК в горизонте
			
	if db.variableExists(w,ds,"TNPH"):
		tnph_norm=Variable(w, ds, "TNPH_NORM", "Neutron Porosity", "v/v")
		tnph_ch=1
		
		kTNPH=float(zoneInfo[w]["20_kTNPH"]) #мультипликативная поправка НК в траспорте
		bTNPH=float(zoneInfo[w]["21_bTNPH"]) #аддитивная поправка в НК в транспорте
		
		kTNPH_hor=float(zoneInfo[w]["23_kTNPH_hor"]) #мультипликативная поправка НК в горизонте
		bTNPH_hor=float(zoneInfo[w]["24_bTNPH_hor"]) #аддитивная поправка в НК в горизонте
		
	if db.variableExists(w,ds,"GR"):
		gr_norm=Variable(w, ds, "GR_NORM", "Gamma Ray", "gAPI")
		gr_ch=1
		
		kGR=float(zoneInfo[w]["10_kGR"]) #мультипликативная поправка ГК в траспорте
		bGR=float(zoneInfo[w]["11_bGR"]) #аддитивная поправка в ГК в транспорте
		
		kGR_hor=float(zoneInfo[w]["13_kGR_hor"]) #мультипликативная поправка ГК в горизонте
		bGR_hor=float(zoneInfo[w]["14_bGR_hor"]) #аддитивная поправка в ГК в горизонте
	
	if db.variableExists(w,ds,"RT"):
		rt_norm=Variable(w, ds, "RT_NORM", "Formation Resistivity", "Ohmm")
		rt_ch=1
		
		kRT=float(zoneInfo[w]["50_kRT"]) #мультипликативная поправка УЭС в траспорте
		bRT=float(zoneInfo[w]["51_bRT"]) #аддитивная поправка в УЭС в транспорте
		
		kRT_hor=float(zoneInfo[w]["52_kRT_hor"])#мультипликативная поправка ГК в горизонте
		bRT_hor=float(zoneInfo[w]["53_bRT_hor"]) #аддитивная поправка в УЭС в горизонте
	
	#применение коэффициентов к кривым в поточесном режиме
	for j in range(MD.referenceSize()):
		
		if rt_ch==1 and rt[j]!=MissingValue:
			if horizon[j]==0:
				rt_norm[j]=kRT*rt[j]+bRT
			else:
				rt_norm[j]=kRT_hor*rt[j]+bRT_hor
		
		if den_ch==1 and rhob[j]!=MissingValue:
			if horizon[j]==0:
				rhob_norm[j]=kDEN*rhob[j]+bDEN
			else:
				rhob_norm[j]=kDEN_hor*rhob[j]+bDEN_hor

		if tnph_ch==1 and tnph[j]!=MissingValue:
			if horizon[j]==0:
				tnph_norm[j]=kTNPH*tnph[j]+bTNPH
			else:
				tnph_norm[j]=kTNPH_hor*tnph[j]+bTNPH_hor

		if dt_ch==1 and dt[j]!=MissingValue:
			if horizon[j]==0:
				dt_norm[j]=kDT*dt[j]+bDT
			else:
				dt_norm[j]=kDT_hor*dt[j]+bDT_hor
				
			
		if gr_ch==1 and gr[j]!=MissingValue:
			if horizon[j]==0:
				
				gr_norm[j]=kGR*gr[j]+bGR
			else:
				gr_norm[j]=kGR_hor*gr[j]+bGR_hor
			
	if den_ch==1:
		rhob_norm.save()
	if dt_ch==1:
		dt_norm.save()
	if gr_ch==1:
		gr_norm.save()
	if rt_ch==1:
		rt_norm.save()
	if tnph_ch==1:
		tnph_norm.save()

	#Создание гистограмм по всем методам для транспорта и горизонта если надо
	gr_norm_hist=np.array(gr_norm.values())[start_kuz:stop_kuz]
	gr_norm_hist=gr_norm_hist[gr_norm_hist>0]
	log_hist(gr_kuz,gr_norm_hist,"GR",w,gr_norm_val,gr_kuz_p,np.percentile(gr_norm_hist,50))
	
	rhob_norm_hist=np.array(rhob_norm.values())[start_kuz:stop_kuz]
	rhob_norm_hist=rhob_norm_hist[bhf_kuz==0]
	rhob_norm_hist=rhob_norm_hist[rhob_norm_hist>0 & (rhob_norm_hist<2.35)]
	log_hist(rhob_kuz,rhob_norm_hist,"RHOB",w,rhob_norm_val,rhob_kuz_p,np.percentile(rhob_norm_hist,90))
	
	tnph_norm_hist=np.array(tnph_norm.values())[start_kuz:stop_kuz]
	tnph_norm_hist=tnph_norm_hist[bhf_kuz==0]
	tnph_norm_hist=tnph_norm_hist[tnph_norm_hist>0]
	log_hist(tnph_kuz,tnph_norm_hist,"TNPH",w,tnph_norm_val,tnph_kuz_p,np.percentile(tnph_norm_hist,50))
	
	rt_norm_hist=np.array(rt_norm.values())[start_kuz:stop_kuz]
	rt_norm_hist=rt_norm_hist[rt_norm_hist>0]
	log_hist(rt_kuz,rt_norm_hist,"RT",w,rt_norm_val,rt_kuz_p,np.percentile(rt_norm_hist,10))
	
	if hor_ch:
		gr_norm_hist=np.array(gr_norm.values())[start_horizon:stop_horizon]
		gr_norm_hist=gr_norm_hist[gr_norm_hist>0]
		log_hist(gr_horizon,gr_norm_hist,"GR",w,gr_transp_p+gr_kuz_delta,gr_horizon_p,np.percentile(gr_norm_hist,90),True)

		rhob_norm_hist=np.array(rhob_norm.values())[start_horizon:stop_horizon]
		rhob_norm_hist=rhob_norm_hist[rhob_norm_hist>0 & (rhob_norm_hist<2.4)]
		log_hist(rhob_horizon,rhob_norm_hist,"RHOB",w,rhob_transp_p+rhob_kuz_delta,rhob_horizon_p,np.percentile(rhob_norm_hist,90),True)
		
		tnph_norm_hist=np.array(tnph_norm.values())[start_horizon:stop_horizon]
		tnph_norm_hist=tnph_norm_hist[tnph_norm_hist>0]
		log_hist(tnph_horizon,tnph_norm_hist,"TNPH",w,tnph_transp_p+tnph_kuz_delta,tnph_horizon_p,np.percentile(tnph_norm_hist,50),True)
		
		rt_norm_hist=np.array(rt_norm.values())[start_horizon:stop_horizon]
		rt_norn_hist=rt_norm_hist[(fld_horizon!=1)&(fld_horizon<=4)]
		rt_norm_hist=rt_norm_hist[(rt_norm_hist>0)&(rt_norm_hist<10)]
		log_hist(rt_horizon,rt_norm_hist,"RT",w,rt_transp_p,rt_horizon_p,np.percentile(rt_norm_hist,5),True)
	

print("done")
