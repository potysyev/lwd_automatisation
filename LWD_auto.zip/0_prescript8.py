from math import *
from TechlogMath import *
from operator import *
import sys
if sys.version_info[0]==3:
    from six.moves import range

PI     = 3.14159265358979323846
PIO2   = 1.57079632679489661923
PIO4   = 7.85398163397448309616E-1
SQRT2  = 1.41421356237309504880
SQRTH  = 7.07106781186547524401E-1
E      = exp(1)
LN2    = log(2)
LN10   = log(10)
LOG2E  = 1.4426950408889634073599
LOG10E = 1.0 / LN10
MissingValue = -9999
def iif(condition, trueResult=MissingValue, falseResult=MissingValue):
	if condition:
		return trueResult
	else:
		return falseResult

#Declarations
#The dictionary of parameters v2.0
#name,bname,type,family,measurement,unit,value,mode,description,group,min,max,list,enable,iscombocheckbox,isused
parameterDict = {}
try:
	if Parameter:
		pass
except NameError:
	class Parameter:
		def __init__(self, **d):
			pass

__author__ = """Victor POTYSYEV (VPOT)"""
__date__ = """2018-08-12"""
__version__ = """1.0"""
__pyVersion__ = """3"""
__group__ = """"""
__suffix__ = """"""
__prefix__ = """"""
__applyMode__ = """0"""
__awiEngine__ = """v1"""
__layoutTemplateMode__ = """"""
__includeMissingValues__ = """True"""
__keepPreviouslyComputedValues__ = """True"""
__areInputDisplayed__ = """True"""
__useMultiWellLayout__ = """True"""
__idForHelp__ = """"""
__executionGranularity__ = """full"""
#DeclarationsEnd
#Данным скриптом выполняется создание основного датасета, перенос и сшивка данных из вшиваемого датасета в основной 

import TechlogPlot as tp
import TechlogStat as ts

from six.moves import range

#используемые датасеты необходимо вводить вручную
mainds="STAT_CPI"
tieds="Final Las_MEM_RNX-XXX-X-XXXG"
imageds="" 
zds_cycles="TOPS_cycles"
zds="TOPS_PK1_AK_latest"
#Объявление доп переменных
k=0
realtime=True #флаг данных в рельном времени
ntype="" #флаг подрядчика 

RT_DEPTH=16  #Поменять RT_DEPTH в случае плохого качества и тогда будет использовать 27 
if RT_DEPTH==16:
	rt_hal=['R15PC','ARH16PC']
else:
	rt_hal=['R27PC','ARH32PC']


#словать мнемоник сервисных компаний В поле IND необходимо указывать имя уникальной кривой для даннгого подрядчика и типа записи.
#ключ это стандартное имя в основном датасете, а значение имя кривой подрядчика
servicedict={
'HAL': {'IND':'ALCDLC','GR':'DGRC','TNPL':'TNPL','TNPS':'TNPS','RHOB':'ALCDLC','RHOBB':'ALCDBQ','RHOBT':'ALCDTQ','RT':rt_hal[0],'RT2':rt_hal[1], 'CALI':'ALHSI'}, 
'HALRT':{'IND':'ALCDLC-T','GR':'DGRC','TNPL':'TNPL-T','TNPS':'TNPS-T','RHOB':'ALCDLC-T','RHOBB':'ALCDBQ-T','RHOBT':'ALCDTQ-T','RT':rt_hal[0]+"-T",'RT2':rt_hal[1]+"-T",'CALI':'ALHSI'}, 
'WF':{'IND':'RHOB_rec','GR':'HAGRT','TNPL':'NPLS','TNPS':'NPSS','RHOB':'RHOB_rec','RHOBB':'RHOBB','RHOBT':'RHOBT','RT':'RPS2','RT2':'RPM2','CALI':'CALIX'}, 
'WFRT':{'IND':'RHOBC','GR':'HAGRT','TNPL':'NPLS','TNPS':'NPSS', 'RHOB':'RHOBB','RHOBB':'RHOBB','RHOBT':'RHOBT','RT':'RPS2','RT2':'RPM2','CALI':'CALIX'},
'BH': {'IND':'BDCFM','GR':'GR1CFM','TNPL':'NPCKTPLNFM','TNPS':'NPCKTPSNFM','RHOB':'BDCFM','RHOBB':'RHOBB','RHOBT':'RHOBT','RT':'RPCHM','RT2':'RPCSHM', 'CALI':'CALCFM'}, 
'BHRT':{'IND':'BDCX','GR':'GR1СX','TNPL':'NPCKTPLNX','TNPS':'NPCKTPSNX','RHOB':'BDCX','RHOBB':'RHOBB','RHOBT':'RHOBT','RT':'RPCSHX','RT2':'RPCLX','CALI':'CALCX'}}

#основной цикл по выделенным скважинам
for w in db.selectedWellList():
	print(w)
	mainds_ch=False #флаг наличия основного датасета
	tieds_ch=False #флаг наличия привязочного датасета
	#hords_ch=False #флаг наличия горищонтального датасета
	imageds_ch=False #флаг наличия  датасета имиджера
	hor_ch=True #флаг принадлежности к горизонтальной части
	den_ch=0  #флаг наличия  плотности
	rt_ch=0  #флаг наличия  УЭС
	dt_ch=0 #флаг наличия  Акустики
	gr_ch=0 #флаг наличия  ГК
	tnph_ch=0 #флаг наличия  НК
	ch_section_flag=False #флаг принадлежности к горизонтальной части
	a=MissingValue #вспомогательная переменная для детектирования горизонта
	l=[]  #список для сшивки имиджа из кривых
	n="" #вспомогательная переменная для переноса кривых в основной датасет
	col=0 #вспомогательная переменная для сшивки имиджа
	nodat=False #
	
	if db.datasetExists(w,mainds): # проверка наличия основного датасета
		mainds_ch=True
		
	if db.datasetExists(w,tieds):  # проверка наличия вшиваемого датасета на случай если есть ошибка в переменной tieds
		tieds_ch=True
		#определение подрядчика вшиваемого датасета
		for k in servicedict: 
			if db.variableExists(w,tieds,servicedict[k]['IND']): #перебиратся все записи в словаре до обнаружения индикаторной кривой в пришиваемом датасете
				ntype=k #подрядчик и тип записи сораняется в переменную
				break
		if ntype=="":
			print("Не удалось определить подрядчика")
			break
		#RM vs RT ID
		if ntype[-2:]!="RT":
			realtime=False
	elif tieds=="":
		print("Датасет для сшивки не был указан. Выполняется пересчет флагов")
	else:
		print("Датасет указан неверно")
		break
	print(ntype, "Realtime ", realtime)

	#сбор имиджа для Халибертон
	if db.datasetExists(w,imageds) and (ntype=="HAL" or ntype=="HALRT"):
		imageds_ch=True 

		for x in range(16): #16 это максимальное количество секторов к которому мы приводим имидж
			if db.variableExists(w,imageds,"ALCD1H-T") or db.variableExists(w,imageds,"ALCD01H-T") :
				rh = "ALCD{}H-T".format(x + 1)
			elif db.variableExists(w,imageds,"ALCD10H") and x<9:
				rh = "ALCD0{}H".format(x + 1)
			else:
				rh = "ALCD{}H".format(x + 1)
			if db.variableExists(w,imageds,rh):
				l+=db.variableLoad(w, imageds, rh)
				col+=1
		if db.variableExists(w,imageds,"ROSI"):
			db.variableDelete(w,imageds,"ROSI")
		db.arraySave(w,imageds,"ROSI",l,col)
	#переименование имиджей Везерфорд
	elif  db.datasetExists(w,imageds) and (ntype=="WF" or ntype=="WFRT"):
		imageds_ch=True
		if db.variableExists(w,imageds,"RHOYC"):
			if not db.variableExists(w,imageds,"ROSI"):
				db.variableRename(w,imageds,"RHOYC","ROSI")
		elif db.variableExists(w,imageds,"RHOZC"):
			if not db.variableExists(w,imageds,"ROSI"):
				db.variableRename(w,imageds,"RHOZC","ROSI")
	
		db.variableTypeChange(w,imageds,"ROSI","ArrayMatrix") #изменение типа данных имиджа для корректного отображения
		ros=Array(w,imageds,"ROSI",db.arrayColumnSize(w,imageds,"ROSI"),"Borehole Image Density Array","g/cc")
		rhobb=Variable(w,imageds,"RHOBB","Bulk Density","g/cc") 
		rhobt=Variable(w,imageds,"RHOBT","Bulk Density","g/cc") 
		for i in range(0,db.datasetSize(w,imageds)):
			rhobt[i]=ros.value(i,0) #выделяем нижний квадрант
			rhobb[i]=ros.value(i,int(db.arrayColumnSize(w,imageds,"ROSI")/2)) #выделяем верхний квадрант
		rhobb.save()
		rhobt.save()
		if not db.variableExists(w,tieds,"RHOBB"): #копируем верхний и нижний квадранты в основной датасет
			db.variableCopy(w,imageds,"RHOBB",tieds,"RHOBB")
		if not db.variableExists(w,tieds,"RHOBT"):
			db.variableCopy(w,imageds,"RHOBT",tieds,"RHOBT")
	#переименование имиджей Бейкер Хьюз
	elif (ntype=="BH" or ntype=="BHRT") and (db.variableExists(w,tieds,"ABDC01X") or db.variableExists(w,tieds,"ABDCF01M")):
		imageds_ch=True
		imageds=tieds+"_img"
		db.datasetDuplicate(w,tieds,w,imageds)
		for c in db.variableList(w,imageds):
			if c[0:4]!="ABDC" and c!=db.referenceName(w,imageds):
				db.variableDelete(w,imageds,c)
		for x in range(16): #16 это максимальное количество секторов к которому мы приводим имидж
			p=str(x+1).zfill(2)
			if db.variableExists(w,imageds,"ABDC01X"):
				rh = "ABDC{}X".format(p)
			elif db.variableExists(w,imageds,"ABDCF01M") :
				rh = "ABDCF{}M".format(p)
			else:
				rh=""
			if db.variableExists(w,imageds,rh) and rh!="":
				l+=db.variableLoad(w, imageds, rh)
				col+=1
		if db.variableExists(w,imageds,"ROSI") and rh!="":
			db.variableDelete(w,imageds,"ROSI")
		db.arraySave(w,imageds,"ROSI",l,col)
		
		db.variableTypeChange(w,imageds,"ROSI","ArrayMatrix") #изменение типа данных имиджа для корректного отображения
		ros=Array(w,imageds,"ROSI",db.arrayColumnSize(w,imageds,"ROSI"),"Borehole Image Density Array","g/cc")
		rhobb=Variable(w,imageds,"RHOBB","Bulk Density","g/cc") 
		rhobt=Variable(w,imageds,"RHOBT","Bulk Density","g/cc") 
		for i in range(0,db.datasetSize(w,imageds)):
			rhobt[i]=ros.value(i,0) #выделяем нижний квадрант
			rhobb[i]=ros.value(i,int(db.arrayColumnSize(w,imageds,"ROSI")/2)) #выделяем верхний квадрант
		rhobb.save()
		rhobt.save()
		if not db.variableExists(w,tieds,"RHOBB"): #копируем верхний и нижний квадранты в основной датасет
			db.variableCopy(w,imageds,"RHOBB",tieds,"RHOBB")
		if not db.variableExists(w,tieds,"RHOBT"):
			db.variableCopy(w,imageds,"RHOBT",tieds,"RHOBT")
			
	elif imageds=="":
		print("Датасет с имиджем не был указан ")
	else:
		print("Датасет с имиджем был указан не верно ")
		break
	
	#конвертация НК в доли единицы
	if db.variableUnit(w,tieds,servicedict[ntype]['TNPL'])!="v/v":
		if db.variableUnit(w,tieds,servicedict[ntype]['TNPL'])=="P.U." or db.variableUnit(w,tieds,servicedict[ntype]['TNPL'])=="pu" :
			db.variableUnitChange(w,tieds,servicedict[ntype]['TNPL'],"%")
		db.variableUnitConvert(w,tieds,servicedict[ntype]['TNPL'],"v/v")
	if db.variableUnit(w,tieds,servicedict[ntype]['TNPS'])!="v/v":
		if db.variableUnit(w,tieds,servicedict[ntype]['TNPS'])=="P.U." or db.variableUnit(w,tieds,servicedict[ntype]['TNPL'])=="pu" :
			db.variableUnitChange(w,tieds,servicedict[ntype]['TNPS'],"%")
		db.variableUnitConvert(w,tieds,servicedict[ntype]['TNPS'],"v/v")
	
	#переименование ГК для халибертон
	if ntype=="HALRT" and not db.variableExists(w,tieds,servicedict['HALRT']['GR']): #Для случая с Jetlupse
		if db.variableExists(w,tieds,"PGXR-T"):
			db.variableCopy(w,tieds,"PGXR-T",tieds,"DGRC")
	elif ntype=="HAL" and not db.variableExists(w,tieds,servicedict['HAL']['GR']):
		if db.variableExists(w,tieds,"PGXR"):
			db.variableCopy(w,tieds,"PGXR",tieds,"DGRC")
		elif db.variableExists(w,tieds,"PGGR"):
			db.variableCopy(w,tieds,"PGGR",tieds,"DGRC")
	
	#переименовываем RHOB в привязочном датасет чтобы избжать конфилкта в основном
	if  (ntype =="WF" or ntype =="WFRT"): 
		if db.variableExists(w,tieds,"RHOB") and not db.variableExists(w,tieds,"RHOBC"):
			db.variableCopy(w,tieds,"RHOB",tieds,"RHOBC")
			db.variableDelete(w,tieds,"RHOB")
			db.variableFamilyChange(w,tieds,"RHOBC","Bulk Density")
			db.variableUnitChange(w,tieds,"RHOBC","g/cc")

	sr=round(db.datasetSamplingRate(w,tieds),1) #шаг квантования
	stpind=db.datasetSize(w,tieds)-1 #индекс конца вшивки в вшиваемом датасете
	
	#Создание и вшивка данных в основной датасет
	if not mainds_ch: #Создание основного датасета и копирование кривых если он отсутсвует в БД
		ref=[round(d*sr,1) for d in range(0,int(round(db.referenceValue(w,tieds,db.datasetSize(w,tieds)-1)/sr,0))+1)] #создание списка содержащего глубины от 0 до самой глубокой величины во вшиваемом датасете
		db.datasetCreate(w,mainds,"MD","Measured Depth","m",ref)
		for v in db.variableList(w,tieds): #Перебор и копирование всех кривых 
			db.variableCopy(w,tieds,v,mainds,v)
		for var in db.variableList(w,mainds): #В случае кривых реального времени халибертон удаляются суффиксы 
			if var[-2:]=="_T" or var[-2:]=="-T":
				db.variableRename(w,mainds,var,var[0:-2])

		print("Новый датасет создан")
	else: #Вставка вшиваемого датасета в уже существующий основной
		x=db.variableLoad(w, mainds, "GR")
		all_occurrences = [index for index, element in enumerate(x) if element != MissingValue]
		a=all_occurrences[-1]

		tieref=db.variableLoad(w,tieds,db.referenceName(w,tieds)) #список глубин вшиваемого датасета
		mainref=db.variableLoad(w,mainds,db.referenceName(w,mainds)) #список глубин основного датасета
		
		if realtime: 
			if a!=MissingValue: #сшивка рт к данным из памяти
				mind=mainref.index(round(db.referenceValue(w,mainds,a),1))#идекс начала вставки вшиваемого датасета в основной определяется по глубине окончания данных из памяти
				strind=tieref.index(round(db.referenceValue(w,mainds,a),1)) #идекс начала вставки вшиваемого датасета в основной определяется глубиной окончания данных из памяти в основном датасете
			else: #сшивка рт к рт
				mind=len(mainref)-1 #идекс начала вставки вшиваемого датасета в основной определяется конечной глубиной датасета
				strind=tieref.index(round(db.referenceValue(w,mainds,len(mainref)-1),1)) #идекс начала вставки вшиваемого датасета в основной определяется глубиной окончания основного датасета
		elif not realtime:
			if a!=MissingValue: #сшивка памяти с памятью
				mind=mainref.index(round(db.referenceValue(w,mainds,a),1)) #идекс начала вставки вшиваемого датасета в основной определяется по глубине окончания данных из памяти
				strind=tieref.index(round(db.referenceValue(w,mainds,a),1))  #идекс начала вставки вшиваемого датасета в основной определяется глубиной окончания данных из памяти в основном датасете
			else: # замена rt на rt
				mind=mainref.index(round(db.referenceValue(w,tieds,0),1)) #идекс начала вставки вшиваемого датасета в основной определяется по глубине начала вшиваемого датасета
				strind=0 #Берется вшиваемый датсет с 0 индекса
		else: #исключения
			strind=0 
			mind=0
		#функция вставки данных 
		if db.referenceValue(w,mainds,db.datasetSize(w,mainds)-1)<db.referenceValue(w,tieds,db.datasetSize(w,tieds)-1): 
			db.datasetExpand(w,mainds,tieref[tieref.index(round(db.referenceValue(w,mainds,db.datasetSize(w,mainds)-1),1))+1:stpind],db.datasetSize(w,mainds)) #расширение основного датасета по индексам которые определены выше
		
		for var in db.variableList(w,tieds): #перебор всех кривых в пришиваемом датасете для поиска эквивалета в основном
			#print(var)
			nodat=False
			tiedat=db.variableLoad(w,tieds,var)#временный список который содержит все значения кривой var вшиваемого датасета
			if db.variableExists(w,mainds,var): #случай сшивки данных из памяти
				#print var
				mainf=db.variableFamily(w,mainds,var) #запоминаем фемили основной кривой с таким же именем
				mainu=db.variableUnit(w,mainds,var) #запоминаем единицы измерения основной кривой с таким же именем
				n=var #запоминаем имя вшиваемой кривой
				dat=db.variableLoad(w,mainds,var) #временный список который содержит все значения кривой var основного датасета
			elif db.variableExists(w,mainds,var[0:-2]) and (var[-2:]=="_T" or var[-2:]=="-T"): #случай сшивки данных из реального времени Халибуртон
				mainf=db.variableFamily(w,mainds,var[0:-2])
				mainu=db.variableUnit(w,mainds,var[0:-2])
				n=var[0:-2]
				dat=db.variableLoad(w,mainds,var[0:-2])
			else: #случай сшивки электрометрии с другим названием кривых. 
				mainf=db.variableFamily(w,tieds,var)
				mainu=db.variableUnit(w,tieds,var)
				if realtime:
					if var=="ARH16PC-T":
						dat=db.variableLoad(w,mainds,"R15PC")
						n="R15PC"
					elif var=="ARH48PC-T":
						dat=db.variableLoad(w,mainds,"R39PC")
						n="R39PC"
					else:
						nodat=True
				else:
					
					if var=="R15PC" :                           
						dat=db.variableLoad(w,mainds,"ARH16PC")
						n="ARH16PC"
					elif var=="R27PC" :
						dat=db.variableLoad(w,mainds,"ARH32PC")
						n="ARH32PC"
					elif var=="R39PC" :
						dat=db.variableLoad(w,mainds,"ARH48PC")
						n="ARH48PC"
					elif var=="R16AC" :
						dat=db.variableLoad(w,mainds,"ARH16AC")
						n="ARH16AC"
					elif var=="R27AC" :
						dat=db.variableLoad(w,mainds,"ARH32AC")
						n="ARH32AC"
					elif var=="R39AC" :
						dat=db.variableLoad(w,mainds,"ARH48AC")
						n="ARH48AC"
					else: #Кривая которая не была найдена в основном датасете в дальнейшем не используется. 
						nodat=True
			if not nodat:
				dat[mind:mind+(stpind-strind)]=tiedat[strind:stpind]
				db.variableSave(w,mainds,n, mainf,mainu,dat)
		
	#Создание флагов и стандартизация имен кривых для интерпретации					
	
	MD=Variable(w, mainds, db.referenceName(w,mainds))
	if not db.variableExists(w,mainds,"TVDSS"):
		db.variableCopy(w,"Index","TVDSS",mainds)
	else:
		db.variableDelete(w,mainds,"TVDSS")
		db.variableCopy(w,"Index","TVDSS",mainds)
	tvdss=Variable(w, mainds, "TVDSS")
	calc=Variable(w, mainds, "CALC", "Calcite Flag","unitless" )
	cut=Variable(w, mainds, "cut", "General Flag", "unitless")
	por_user=Variable(w, mainds, "POR_USER", "General Flag", "unitless")
	bperm=Variable(w, mainds, "BPERM", "General Flag", "unitless")
	sand=Variable(w, mainds, "SAND","General Flag","unitless")
	fld=Variable(w, mainds, "FLD", "Fluid Code","unitless")
	coal=Variable(w, mainds, "COAL","Coal Flag","unitless")
	shale=Variable(w, mainds, "SHALE", "General Flag","unitless")
	tnph=Variable(w, mainds, "TNPH","Neutron porosity","v/v")
	mw=Variable(w,mainds,"MW_flag","General Flag","unitless")
	bhf=Variable(w,mainds,"BHF","Bad Hole Flag","unitless")
	hor=Variable(w,mainds,"HORIZON","General Flag","unitless")
	rec_flag=Variable(w,mainds,"REC_FLAG","General Flag","unitless")
	
	calc.setGroupName("_Tech_curves")
	cut.setGroupName("_Tech_curves")
	sand.setGroupName("_Tech_curves")
	coal.setGroupName("_Tech_curves")
	shale.setGroupName("_Tech_curves")
	fld.setGroupName("_EVAL")
	por_user.setGroupName("_Tech_curves")
	bperm.setGroupName("_Tech_curves")
	mw.setGroupName("_Tech_curves")
	bhf.setGroupName("_Tech_curves")
	hor.setGroupName("_Tech_curves")
	rec_flag.setGroupName("_Tech_curves")
	

	#создание  кривой RT из вшитих данных выполняется каждый раз после вшивки исходных данных
	if db.variableExists(w,mainds,"RT"):
		db.variableDelete(w,mainds,"RT")
	if db.variableExists(w,mainds,servicedict[ntype]['RT']): #Имя кривой в основном датасете берется из словаря servicedict
		db.variableCopy(w,mainds,servicedict[ntype]['RT'],mainds,"RT")
		rt_ch=1
	elif db.variableExists(w,mainds,servicedict[ntype]['RT2']): #Альтернативное Имя кривой в основном датасете берется из словаря servicedict
		db.variableCopy(w,mainds,servicedict[ntype]['RT2'],mainds,"RT")
		rt_ch=1
	else:
		print("Кривая RT не найдена")
		rt_ch=0

	if rt_ch==1:
		rt=Variable(w,mainds,"RT")
		db.variableFamilyChange(w,mainds,"RT","Formation Resistivity")
		db.variableUnitChange(w,mainds,"RT","Ohmm")
		
	
	#создание и переименовние кривой GR выполняется каждый раз после вшивки исходных данных
	if db.variableExists(w,mainds,"GR"):
		db.variableDelete(w,mainds,"GR")
	if db.variableExists(w,mainds,servicedict[ntype]['GR']):#Имя кривой в основном датасете берется из словаря servicedict
		db.variableCopy(w,mainds,servicedict[ntype]['GR'],mainds,"GR")
		db.variableFamilyChange(w,mainds,"GR","Gamma Ray")
		db.variableUnitChange(w,mainds,"GR","gAPI")
		gr=Variable(w, mainds, "GR")
		
	#загрузка квадрантов в переменные для дальнейшей обработки
	if db.variableExists(w,mainds,servicedict[ntype]['RHOB']) or db.variableExists(w,mainds,servicedict[ntype]['RHOBB']) :
		density=Variable(w, mainds, "DENSITY", "General Flag","unitless") #флаг для индикации вшивки сектора плотности
		density.setGroupName("_Tech_curves")
		rhob=Variable(w, mainds,'RHOB',"Bulk Density", "g/cm3") 
		alcdbq=Variable(w, mainds, servicedict[ntype]['RHOBB'], "Bulk Density", "g/cm3")
		alcdtq=Variable(w, mainds, servicedict[ntype]['RHOBT'], "Bulk Density", "g/cm3")
		alcdlc=Variable(w, mainds, servicedict[ntype]['RHOB'], "Bulk Density", "g/cm3")
		den_ch=1
	
	#создание и переименовние кривой TNPH выполняется каждый раз после вшивки исходных данных
	if 	db.variableExists(w,mainds,"TNPH"):
		db.variableDelete(w,mainds,"TNPH")
		tnph_ch=1
	if db.variableExists(w,mainds,servicedict[ntype]['TNPL']):
		db.variableCopy(w,mainds,servicedict[ntype]['TNPL'],mainds,"TNPH")
	
	#создание и переименовние кривой CALI выполняется каждый раз после вшивки исходных данных
	if  db.variableExists(w,mainds,"CALI"):
		db.variableDelete(w,mainds,"CALI")
	if db.variableExists(w,mainds,servicedict[ntype]['CALI']):
		db.variableCopy(w,mainds,servicedict[ntype]['CALI'],mainds,"CALI")

	#Идем по всем глубинам основного датасета
	for i in range(0,db.datasetSize(w,mainds)):
		#Создание кривой RHOB из секторов используя флаг DENSITY по умолчанию бест бин квадрант, нижний или верхний нужно указывать явно
		if den_ch==1:
			if density[i]==MissingValue:
				density[i]=0
				rhob[i]=alcdlc[i] 
			elif density[i]==1:
				rhob[i]=alcdtq[i]
			elif density[i]==2:
				rhob[i]=alcdbq[i] 
			else: 
				rhob[i]=alcdlc[i] 
		#определение точки начала данных хвостовика. Ищем пропуск данныз между секциями
		if tvdss[i]>1030: #это место не может быть выше 1030 абс м.
			if rhob[i]==MissingValue and tnph[i]==MissingValue: #ищем начало интервала отсутсвия значений между секциями сверху
				ch_section_flag=True
			if ch_section_flag and rhob[i]!=MissingValue and tnph[i]!=MissingValue: #Ищем начало данных горизонтальной секции
				hor[i]=1
			else:
				hor[i]=0
		else:
			hor[i]=0

		#заполнение флагов нулевыми значениями для последующей ручной корректировки
		if mw[i]==MissingValue:
			mw[i]=0
		if calc[i]==MissingValue:
			calc[i]=0
		if cut[i]==MissingValue:
			cut[i]=0
		if por_user[i]==MissingValue:
			por_user[i]=0
		if bperm[i]==MissingValue:
			bperm[i]=0
		if sand[i]==MissingValue:
			sand[i]=0
		if coal[i]==MissingValue:
			coal[i]=0
		if shale[i]==MissingValue:
			shale[i]=0
		if bhf[i]==MissingValue:
			bhf[i]=0
		#Если данные из памяти меняеть флаг на 1 
		if rec_flag[i]!=1 :
			if realtime:
				rec_flag[i]=0
			else:
				rec_flag[i]=1
		#Значения кривой насыщения определяются по принятым контактам по умолчаню для дальнейшей корректировки в ручную
		if fld[i]==MissingValue and tvdss[i]<1024:
			fld[i]=3
		elif fld[i]==MissingValue and tvdss[i]>1024 and tvdss[i]<1044:
			fld[i]=2
		elif fld[i]==MissingValue and tvdss[i]>1044:
			fld[i]=1
	
	#сохранение изменений
	calc.save()
	cut.save()
	sand.save()
	fld.save()
	coal.save()
	shale.save()
	por_user.save()
	bperm.save()
	mw.save()
	bhf.save()
	hor.save()
	rec_flag.save()
	if den_ch==1:
		density.save()
		rhob.save()
		den_ch=0
	
	#модель обработки имиджа
	if imageds_ch and db.datasetExists(w,mainds): 
		name=""
		horizon=db.variableLoad(w, mainds, "HORIZON") 
		try:
			h=horizon.index(1) #ищем начало горизонтальной секции определнной в модуле инициализации флагов
		except:
			h=MissingValue
			
		if db.referenceValue(w,imageds,db.datasetSize(w,imageds)-1)<db.referenceValue(w,mainds,h) or h==MissingValue: #если глубина конца вшиваемого датасета имиджа меньше начала флага хвостовика то задается следующее имя
			name="ROSI_TRANSP"
		elif db.referenceValue(w,imageds,db.datasetSize(w,imageds)-1)>db.referenceValue(w,mainds,h) and h!=MissingValue:
			name="ROSI_HOR"
			
		if db.variableExists(w,mainds,name): #сушествующие имиджи с именами выше удаляются.
			db.variableDelete(w,mainds,name)
		

		db.variableCopy(w,imageds,"ROSI",mainds,name) #копируется имидж из датасета имиджа в основной с выбранным именем
		
		#модель сшивки имиджей транспорта и горизонта с учетом расницы в количестве секторов
		transp_ch=True
		hor_ch=True
		if db.variableExists(w,mainds,"ROSI_TRANSP"):
			rosi_transp=Array(w,mainds,"ROSI_TRANSP")
		else:
			transp_ch=False
			
		if db.variableExists(w,mainds,"ROSI_HOR"):
			rosi_hor=Array(w,mainds,"ROSI_HOR")
		else:
			hor_ch=False
		columns=0
		
		if transp_ch and hor_ch: #определение количства секторов имиджа в основном датасете
			if db.arrayColumnSize(w,mainds,"ROSI_TRANSP")==16 or db.arrayColumnSize(w,mainds,"ROSI_HOR")==16:
				columns=16
			else:
				columns=8
			
			rosi=Array(w,mainds,"ROSI",columns,"Borehole Image Density Array","g/cc")
			
			for i in range(0,db.datasetSize(w,mainds)):
				for j in range(0, columns):
					if db.arrayColumnSize(w,mainds,"ROSI_TRANSP")!=columns: 
						if rosi_transp.value(i,j//2)!=MissingValue:
							rosi.setValue(i,j//2, rosi_transp.value(i,j//2))
					else:
						if rosi_transp.value(i,j)!=MissingValue:
							rosi.setValue(i,j,rosi_transp.value(i,j))
						 
					if db.arrayColumnSize(w,mainds,"ROSI_HOR")!=columns:
						if rosi_hor.value(i,j//2)!=MissingValue:
							rosi.setValue(i,j,rosi_hor.value(i,j//2))
					else:
						if rosi_hor.value(i,j)!=MissingValue:
							rosi.setValue(i,j, rosi_hor.value(i,j))
				if i%100==0:
					print("Сшивка имиджа {} %".format(round(i/db.datasetSize(w,mainds)*100,2)))	
					
			rosi.save()
			if transp_ch and not realtime: #удаление лишних кривых
				db.variableDelete(w,mainds,"ROSI_TRANSP")
				db.variableDelete(w,mainds,"ROSI_HOR")
		else: #Если нет необходимости сшивать две секции пока то переименовывается существующая 
			if transp_ch:
				db.variableCopy(w,mainds,"ROSI_TRANSP",mainds,"ROSI")

			elif hor_ch:
				db.variableCopy(w,mainds,"ROSI_HOR",mainds,"ROSI")

	#Значения глубин пластов по умолчанию
	zds_td=[1200,1250,1350,1400]
	zds_n=["BER","KUZ","PK1",""]
	zds_cycles_td=[1350,1400,1420,1500,1501]
	zds_cycles_n=["Top_PK1","Cycle 2","TAP","bot_PK1",""]
	
	#создание зонаций если они не сущестуют в БД
	if not db.datasetExists(w,zds):
		db.datasetCreate(w,zds,"MD","Measured Depth","m",zds_td)
		db.variableSave(w,zds,"Surface", "Zone Name","",zds_n)
		print("ПОПРАВЬ ДАТАСЕТ {}".format(zds))
	if not db.datasetExists(w,zds_cycles):
		db.datasetCreate(w,zds_cycles,"MD","Measured Depth","m",zds_cycles_td)
		db.variableSave(w,zds_cycles,"Surface", "Zone Name","",zds_cycles_n)
		print("ПОПРАВЬ ДАТАСЕТ {}".format(zds_cycles))
	
	zds_n=db.variableLoad(w, zds, "Surface")
	zds_td=db.variableLoad(w, zds, db.referenceName(w,zds))
	zds_cycles_n=db.variableLoad(w, zds_cycles, "Surface")
	zds_cycles_td=db.variableLoad(w, zds_cycles, db.referenceName(w,zds_cycles))
	
	#Обновление подошвы по фактической длинне скважины.
	if zds_n[-1]=="bot_PK1":
		zds_td[-1]=round(db.referenceValue(w,mainds,db.datasetSize(w,mainds)-1),1)
	if zds_cycles_n[-1]=="" or zds_cycles_n[-1]=="bot_PK1":
		zds_cycles_td[-1]=round(db.referenceValue(w,mainds,db.datasetSize(w,mainds)-2),1)
		if zds_cycles_n[-2]=="bot_PK1":
			zds_cycles_td[-2]=round(db.referenceValue(w,mainds,db.datasetSize(w,mainds)-6),1)

	print(w, "done")
	
	#создание стандартного планшета из шаблона
	if tieds_ch==True :
		id = tp.logViewApplyTemplate('Project\\!STAT_eval', w, False)
	
print("ALL DONE")
